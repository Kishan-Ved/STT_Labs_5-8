.. role:: hidden
    :class: hidden-section

algorithms.string
=================

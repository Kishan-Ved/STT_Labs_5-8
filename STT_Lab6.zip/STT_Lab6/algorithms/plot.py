# Updated baseline time
import matplotlib.pyplot as plt
baseline_time = 11.976

# Updated execution times and failure counts
execution_data = [
    ("1", "load", "1", 13.79, 0),
    ("1", "load", "auto", 87.13, 4),
    ("1", "no", "1", 13.06, 0),
    ("1", "no", "auto", 83.65, 4),
    ("auto", "load", "1", 11.87, 0),
    ("auto", "load", "auto", 67.00, "3--4"),
    ("auto", "no", "1", 11.81, 0),
    ("auto", "no", "auto", 70.05, "3--4"),
]

# Compute speedup ratios
speedups = [baseline_time / exec_time for _, _, _, exec_time, _ in execution_data]

# Extract labels and values for plotting
labels = [f"{n}, {dist}, {threads}" for n, dist, threads, _, _ in execution_data]
values = speedups

# Generate bar plot
plt.figure(figsize=(12, 6))
plt.barh(labels, values, color=['orange' for label in labels])
plt.xlabel("Speedup Ratio")
plt.ylabel("Configuration (n, dist, threads)")
plt.title("Speedup Ratios for Different Parallel Execution Configurations")
plt.axvline(x=1, color='gray', linestyle='--', label="Baseline (Sequential)")
plt.legend()
plt.gca().invert_yaxis()  # Invert y-axis for better readability

# Save the plot
# speedup_plot_path = "/mnt/data/speedup_plot_updated.png"
# plt.savefig(speedup_plot_path)

# Show the plot
plt.show()

# Return the path for downloading
speedup_plot_path

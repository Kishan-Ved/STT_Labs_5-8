val_n=(1 auto)
val_dist=(load no)
val_parallel=(1 auto)

file_out="out2.txt"
file_time="time2.txt"

echo "" > "$file_out"
echo "" > "$file_time"

for n in "${val_n[@]}"; do
    for dd in "${val_dist[@]}"; do
        for pp in "${val_parallel[@]}"; do
            total_time=0
            echo -e "n = $n, dist = $dd, parallel-threads = $pp\n" >> "$file_out"
            for i in {1..3}; do
                start_time=$(date +%s.%N)
                pytest -n "$n" --dist "$dd" --parallel-threads "$pp" >> "$file_out" 2>&1
                end_time=$(date +%s.%N)
                duration=$(echo "$end_time - $start_time" | bc)
                total_time=$(echo "$total_time + $duration" | bc)
            done
            average_time=$(echo "$total_time / 3" | bc -l)
            echo -e "\n" >> "$file_out"
            echo "n = $n, dist = $dd, parallel-threads = $pp, avg_time = $average_time" >> "$file_time"
            echo -e "\n" >> "$file_time"
        done
    done
done
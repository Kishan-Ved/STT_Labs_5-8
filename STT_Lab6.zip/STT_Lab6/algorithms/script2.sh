val_n=(1 auto)
dist_values=(load no)
parallel_values=(1 auto)

output_file="out2.txt"
time_file="time2.txt"

echo "" > "$output_file"
echo "" > "$time_file"

for n in "${val_n[@]}"; do
    for dist in "${dist_values[@]}"; do
        for parallel in "${parallel_values[@]}"; do
            total_time=0
            echo -e "n = $n, dist = $dist, parallel-threads = $parallel\n" >> "$output_file"
            for i in {1..3}; do
                start_time=$(date +%s.%N)
                pytest -n "$n" --dist "$dist" --parallel-threads "$parallel" >> "$output_file" 2>&1
                end_time=$(date +%s.%N)
                duration=$(echo "$end_time - $start_time" | bc)
                total_time=$(echo "$total_time + $duration" | bc)
            done
            average_time=$(echo "$total_time / 3" | bc -l)
            echo -e "\n" >> "$output_file"
            echo "n = $n, dist = $dist, parallel-threads = $parallel, avg_time = $average_time" >> "$time_file"
            echo -e "\n" >> "$time_file"
        done
    done
done
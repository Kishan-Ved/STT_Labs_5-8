output_file="time_seq_good_5.txt"

echo "" > "$output_file"

total_time=0

for i in {1..5}; do
    start_time=$(date +%s.%N)
    pytest tests >> "$output_file" 2>&1
    end_time=$(date +%s.%N)
    duration=$(echo "$end_time - $start_time" | bc)
    total_time=$(echo "$total_time + $duration" | bc)
done
average_time=$(echo "$total_time / 5" | bc -l)
echo -e "\n" >> "$output_file"
echo -e "\n" >> "$output_file"
echo "avg_time = $average_time" >> "$output_file"
echo -e "\n" >> "$output_file"
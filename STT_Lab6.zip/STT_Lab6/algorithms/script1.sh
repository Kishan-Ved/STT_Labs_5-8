output_file="out_seq_10.txt"

echo "" > "$output_file"

for i in {1..10}; do
    pytest tests >> "$output_file" 2>&1
    echo -e "\n" >> "$output_file"
done
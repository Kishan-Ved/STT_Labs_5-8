import json
import os
from collections import Counter

# Path to Bandit reports
report_folder = "bandit_reports"

# Initialize counters
severity_counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
confidence_counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
cwe_counts = Counter()
timeline = {}

# Iterate through all Bandit reports
for filename in os.listdir(report_folder):
    if filename.endswith(".json"):
        commit_hash = filename.replace("bandit_report_", "").replace(".json", "")

        with open(os.path.join(report_folder, filename), "r") as f:
            data = json.load(f)

            high, medium, low = 0, 0, 0
            for issue in data.get("results", []):
                severity = issue["issue_severity"]
                confidence = issue["issue_confidence"]
                cwe = issue.get("issue_cwe", "Unknown CWE")

                # Handle CWE field (if it's a dictionary)
                if isinstance(cwe, dict):
                    cwe = cwe.get("id", "Unknown CWE")

                # Count severity levels
                severity_counts[severity] += 1
                confidence_counts[confidence] += 1
                cwe_counts[cwe] += 1

                # Track severity per commit for timeline
                if severity == "HIGH":
                    high += 1
                elif severity == "MEDIUM":
                    medium += 1
                elif severity == "LOW":
                    low += 1

            timeline[commit_hash] = {"HIGH": high, "MEDIUM": medium, "LOW": low}

# Print summary
print("\n==== Bandit Analysis Summary ====")
print(f"Total HIGH severity issues: {severity_counts['HIGH']}")
print(f"Total MEDIUM severity issues: {severity_counts['MEDIUM']}")
print(f"Total LOW severity issues: {severity_counts['LOW']}")

print("\n==== Confidence Level Analysis ====")
print(f"Total HIGH confidence issues: {confidence_counts['HIGH']}")
print(f"Total MEDIUM confidence issues: {confidence_counts['MEDIUM']}")
print(f"Total LOW confidence issues: {confidence_counts['LOW']}")

print("\nTop 5 CWE Vulnerabilities:")
for cwe, count in cwe_counts.most_common(5):
    print(f"{cwe}: {count} occurrences")

# Save timeline data to JSON for visualization
with open("timeline_data.json", "w") as f:
    json.dump(timeline, f, indent=4)

print("\nData saved in 'timeline_data.json' for further analysis.")

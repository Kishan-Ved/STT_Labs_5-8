import json
import matplotlib.pyplot as plt

# Load the JSON file
with open("timeline_data.json", "r") as file:
    data = json.load(file)

# Extract issue counts
commits = list(data.keys())  # List of commit hashes
high_issues = [data[commit]["HIGH"] for commit in commits]
medium_issues = [data[commit]["MEDIUM"] for commit in commits]
low_issues = [data[commit]["LOW"] for commit in commits]

# Create commit indices for x-axis (instead of hashes)
x_indices = list(range(1, len(commits) + 1))

# Plot the issue trends
plt.figure(figsize=(12, 6))  # Set figure size
plt.plot(x_indices, high_issues, marker="o", linestyle="-", label="HIGH Severity", color="red")
plt.plot(x_indices, medium_issues, marker="s", linestyle="--", label="MEDIUM Severity", color="orange")
plt.plot(x_indices, low_issues, marker="^", linestyle=":", label="LOW Severity", color="green")

# Formatting the graph
plt.xlabel("Commits (Ordered by Time)")
plt.ylabel("Issue Count")
plt.title("Issue Count Variation Over Commits")
plt.legend()
plt.grid(True, linestyle="--", alpha=0.6)  # Light grid for readability
plt.xticks(rotation=45)  # Rotate x-axis labels slightly

# Show the graph
plt.show()

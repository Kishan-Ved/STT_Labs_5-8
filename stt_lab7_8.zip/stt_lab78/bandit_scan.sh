#!/bin/bash

# Create a directory for Bandit reports if it doesn't exist
mkdir -p bandit_reports

# Get the last 100 non-merge commits
commits=$(git log --format="%H" --no-merges -n 100)

# Loop through each commit and run Bandit
for commit in $commits; do
    echo "Checking out commit: $commit"
    git checkout "$commit"

    # Run Bandit and save the output
    report_file="bandit_reports/bandit_report_$commit.json"
    bandit -r . --format json -o "$report_file"

    echo "Bandit report saved: $report_file"
done

# Restore the latest commit
git checkout main  # Change 'main' to 'master' if needed
echo "Restored to the latest commit."
